# 双场景提示词模板与历史依据

## 依据边界

2026-11-05 用户反馈记录指出网格错位、小票乱码、人物缺鞋观感；2026-11-06 用户否定首版图。当前读取图片失败，未能查得旧图完整生成提示词，不将连贯场景方案宣称为用户已认可的历史风格。

## 通用模板

替换所有大括号，不向生成接口提交占位符。保持实际词表为唯一内容来源。

```text
Create a polished visual memory palace for exactly 20 English vocabulary words.
Horizontal landscape orientation, 16:9 aspect ratio. A cohesive illustrated double-page spread on warm ivory paper, clear ink outlines, restrained teal and amber accents, natural proportions, readable silhouettes and ample breathing space.

Left: {work setting}; right: {life setting}. Use a few connected foreground, middle-ground and background areas per side, not isolated icon cells. Guide the eye through each side with a subtle spatial route. Let the actions form a story. Keep foreground cues large and avoid competing ornament.

WORK STORY, exactly {work_count} vocabulary cues:
{ordered_work_word_meaning_action_location_mapping}

LIFE STORY, exactly {life_count} vocabulary cues:
{ordered_life_word_meaning_action_location_mapping}

Typography: titles "WORK" and "LIFE", plus only these exact 20 vocabulary labels, once each, in readable dark sans-serif near their corresponding actions: {exact_final_word_list}. No definitions, translations, phonetics or sentences. Keep labels off faces and objects, no dense leader lines.

Prioritize semantic clarity, coherent scenes and legibility over decorative complexity. No numbered icon grid, filler cells, invented writing, watermarks, duplicate labels, malformed bodies or cropped key objects.
```

## 语义映射测试样例

- resort -- 度假地 -- 带客房、行李与露台的山间旅舍 -- 生活背景。
- routine -- 日常程序 -- 主人公每天重复的早餐步骤，用循环箭头示意 -- 生活前景。
- privacy -- 不受打扰的空间 -- 可拉拢帘子的独处角落 -- 旅舍室内。
- incorporate -- 纳入 -- 小拼图正嵌入整体 -- 工作台。
- deduce -- 推断 -- 可见线索指向结论 -- 工作室证据板。
- fluctuate -- 波动 -- 上下起伏的单条曲线 -- 工作室屏幕。

避免把两个词映射到同一泛化物体而失去区别。必要时将多词分配到一个小故事的不同动作中，而非新增装饰分格。
